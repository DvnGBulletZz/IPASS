/***********************************************************************
*  author ::       Kenan Yildirim                                                                                                                                                                                                     
* File ::              main.cpp                                                                                                                                                                                                           
* Date::           29 - 06 - 2022                                                                                                                                                                                                  
* copyright:    Kenan Yildirim 2022
*                                                                                                                                                                                                                                                    
*  Distributed under the Boost Software License, Version 1.0.
* (See accompanying file LICENSE_1_0.txt or copy at 
* http://www.boost.org/LICENSE_1_0.txt)
***********************************************************************/

#include "hwlib.hpp"
//#include "hwlib-glcd-st7789.hpp"
#include "BME280.hpp"
#include "Oled.hpp"
#include "Weerstation.hpp"

int main( void ){	  
   
   namespace target = hwlib::target;

    auto scl = target::pin_oc( target::pins::scl );
   auto sda = target::pin_oc( target::pins::sda );
   
   hwlib::i2c_bus_bit_banged_scl_sda bus(scl, sda);
   auto sw1 = target::pin_in( target::pins::d51);
   auto sw2 = target::pin_in( target::pins::d53);
   
   BME280 bme280 = BME280(bus);
   Oled window = Oled(bus, 0x3c);
   
    Weerstation ws(window, bme280, &bme280, &bme280, &bme280);
//    unsigned int n = 10;
//    ws.testcases(n);
   for(;;){
       ws.readswitch(sw1, sw2);
      ws.print();
      
      hwlib::wait_ms(1);
   }
            
}