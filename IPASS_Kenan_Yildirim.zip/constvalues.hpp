#ifndef CONSTVALUES_HPP
#define CONSTVALUES_HPP

#include <stdint.h>

//  modes
const uint16_t mode_sleep = 0b10110100;
const uint16_t mode_forced = 0b10110001;
const uint16_t mode_normal = 0b10110111;



#endif // CONSTVALUES_HPP
