/***********************************************************************
*  author ::       Kenan Yildirim                                                                                                                                                                                                     
* File ::              BME280.hpp                                                                                                                                                                                                          
* Date::           29 - 06 - 2022                                                                                                                                                                                                  
* copyright:    Kenan Yildirim 2022
*                                                                                                                                                                                                                                                    
*  Distributed under the Boost Software License, Version 1.0.
* (See accompanying file LICENSE_1_0.txt or copy at 
* http://www.boost.org/LICENSE_1_0.txt)
***********************************************************************/
#ifndef BME280_HPP
#define BME280_HPP
#include "hwlib.hpp"
#include "constvalues.hpp"
#include "temp_sensor.hpp"
#include "pressure_sensor.hpp"
#include "humidity_sensor.hpp"



 
   
class BME280 : public temp_sensor, public pressure_sensor, public humidity_sensor
{
	
    int32_t T_fine;
    const uint16_t address= 0x76;
   const uint16_t config = 0xF5;
   const uint16_t ctrl_meas = 0xF4;
   const uint16_t ctrl_hum = 0xF2;
   const uint16_t dig_add1 = 0x88;
   const uint16_t dig_add2 = 0xE1;
   
  const  uint16_t press_reg = 0xF7;
   const uint16_t temp_reg = 0xFA;
   const uint16_t hum_reg = 0xFD;
   
//  modes
    uint16_t mode;

   uint8_t osrs_h = 0b101;
   uint16_t config_byte= 0b01100100;
   uint8_t results[3];
   uint8_t dig_nums[34];
   
   uint16_t dig_T1;
   int16_t dig_T2;
   int16_t dig_T3; 
   
   uint16_t dig_P1;
   int16_t dig_P2;
   int16_t dig_P3; 
   int16_t dig_P4;
   int16_t dig_P5;
   int16_t dig_P6;
   int16_t dig_P7;
   int16_t dig_P8;
   int16_t dig_P9;
   
   uint8_t dig_H1;
   int16_t dig_H2;
   uint8_t dig_H3;
   int16_t dig_H4;
   int16_t dig_H5;
   int8_t dig_H6;
     
   
   double var1; // variable for temperature  formula 
   double var2; // variable for temperature  formula 
    
    hwlib::i2c_bus_bit_banged_scl_sda *bus;
    
public:

    BME280(hwlib::i2c_bus_bit_banged_scl_sda & bus) {
        this->bus = &bus;
        set_settings();
        setcompensation();
    }
    
    
    void set_settings();
    
    void setmode(const uint16_t& mode);
    
    int calcDigword(int nr);
    
    void setcompensation();
    
    
    int32_t get_raw(uint8_t & msb, uint8_t & lsb, uint8_t & xlsb );
    
    double gettemp() override;
    
    int getpressure() override;
    
    double gethumidity() override;
    

};

#endif // BME280_HPP
