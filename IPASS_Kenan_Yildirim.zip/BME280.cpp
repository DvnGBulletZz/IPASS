/***********************************************************************
*  author ::       Kenan Yildirim                                                                                                                                                                                                 
* File ::              BME280.cpp                                                                                                                                                                                                          
* Date::           29 - 06 - 2022                                                                                                                                                                                                  
* copyright:    Kenan Yildirim 2022
*                                                                                                                                                                                                                                                    
*  Distributed under the Boost Software License, Version 1.0.
* (See accompanying file LICENSE_1_0.txt or copy at 
* http://www.boost.org/LICENSE_1_0.txt)
***********************************************************************/
#include "BME280.hpp"


 /// @file

    /// \brief
    /// Set settings of BME280
    /// \details
    /// function to initilize the mode of the chip and add filters and standbytimer and sampling mode of the humiditysensor
  
void BME280::set_settings(){
    // config to add filter and standby timer
    { hwlib::i2c_write_transaction wtrans = ((hwlib::i2c_bus*)(bus))->write(address);
    wtrans.write(config);
    wtrans.write(config_byte);}
    

    
    { hwlib::i2c_write_transaction wtrans = ((hwlib::i2c_bus*)(bus))->write(address);
    wtrans.write(ctrl_hum);
    wtrans.write(osrs_h);}
    
    
}

    /// \brief
    /// Set mode of BME280
    /// \details
    // sets the mode of the bme280 can set to sleep/forced/normal
void BME280::setmode(const uint16_t& mode){
    //     control to changes modes 
        { hwlib::i2c_write_transaction wtrans = ((hwlib::i2c_bus*)(bus))->write(address);
        wtrans.write(ctrl_meas);
        wtrans.write(mode);}
        
        hwlib::cout << mode << "mode" << hwlib::endl;
    
    }

 /// \brief
    /// shift dig nums
    /// \details
    ///shifts numbers into the total dig value
int BME280::calcDigword(int nr){
    int dig = (dig_nums[nr+1] << 8) | dig_nums[nr];
    return dig;
    }

    /// \brief
    /// set compensation values
    /// \details
    /// function that runs once to get the const values that are allready in the chip to calculate  the right values for the sensors

void BME280::setcompensation(){
         // get the compensation values 
    { hwlib::i2c_write_transaction wtrans = ((hwlib::i2c_bus*)(bus))->write(address);
        wtrans.write(dig_add1);}

    { hwlib::i2c_read_transaction rtrans = ((hwlib::i2c_bus*)(bus))->read(address);
        rtrans.read(dig_nums, 25);}

    // MAKE dig values bij putting the MSB and LSB in 1 unsigned short
    dig_T1 = calcDigword(0);
    
    // same here but with Signed Short
    dig_T2 = (int16_t)calcDigword(2);
    
    dig_T3 = (int16_t)calcDigword(4);
	// compensation values for Pressure 
    dig_P1 = calcDigword(6);    
    dig_P2 = calcDigword(8);    
    dig_P3 = (int16_t)calcDigword(10);    
    dig_P4 = (int16_t)calcDigword(12);    
    dig_P5 = (int16_t)calcDigword(14);    
    dig_P6 = (int16_t)calcDigword(16);    
    dig_P7 = (int16_t)calcDigword(18);    
    dig_P8 = (int16_t)calcDigword(20);    
    dig_P9 = (int16_t)calcDigword(22);
    // compensation values for Humidity
    dig_H1 = (uint8_t)dig_nums[24];
    // compensation values from 0xA1 to last adress
    { hwlib::i2c_write_transaction wtrans = ((hwlib::i2c_bus*)(bus))->write(address);
        wtrans.write(dig_add2);}

    { hwlib::i2c_read_transaction rtrans = ((hwlib::i2c_bus*)(bus))->read(address);
        rtrans.read(dig_nums, 7);}
        
        
    dig_H2 = (int16_t)calcDigword(0);
    
    dig_H3 = (uint8_t)dig_nums[2];
    
    uint8_t mask= 0b00001111;
    dig_H4 = (int16_t)dig_nums[3] << 4;
    uint8_t maskedlsb = dig_nums[4] & mask;
    dig_H4 |= (int16_t)maskedlsb;
    
    uint8_t shiftedright = dig_nums[4] >> 4;
    dig_H5 = (int16_t)dig_nums[5] << 4;
    dig_H5 |= (int16_t)shiftedright;
    
    dig_H6 = (int8_t)dig_nums[6];
}

    /// \brief
    /// get raw values of sensors
    /// \details
    /// get the raw values from the sensors by putting all the bytes into 1 32 bit integer

	// put the raw byte values combined into a 20 bit number
 int32_t BME280::get_raw(uint8_t & msb, uint8_t & lsb, uint8_t & xlsb ){
    int32_t raw_output = 0x000;
    xlsb >>= 4;
    raw_output = (raw_output|msb) << 8;
    raw_output = (raw_output|lsb) <<4;
    raw_output = raw_output | xlsb;
    return raw_output;
}

    /// \brief
    /// get temperature sensor bytes and actual temperature value
    /// \details
    /// function to get the 3 bytes from the temperature sensor and calculate the actual temperature in Celcius (C)
 double BME280::gettemp() {
        
    { hwlib::i2c_write_transaction wtrans = ((hwlib::i2c_bus*)(bus))->write(address);
    wtrans.write(temp_reg);}

      // read results from temperature adress in Celcius(C)
    { hwlib::i2c_read_transaction rtrans = ((hwlib::i2c_bus*)(bus))->read(address);
        rtrans.read(results, 3);}
    int32_t raw_temp = get_raw(results[0], results[1], results[2]);
    
    // formuale for getting the temperature in Celcius 
    var1=(((double)raw_temp)/16384.0-((double)dig_T1)/1024.0)*((double)dig_T2);
    var2=((((double)dig_T1)/131072.0 - ((double)dig_T1)/8192)*(((double)raw_temp)/131072.0-((double)dig_T1)/8192.0))* ((double)dig_T3);
    double Temperature =(var1+var2)/5120.0;
    T_fine=(var1+var2);
    return Temperature;
}

/// \brief
    /// get pressure sensor bytes and actual pressure value
    /// \details
    /// function to get the 3 bytes from the pressure sensor and calculate the actual Pressure in Pascal (P)
    
// function for getting pressure value in Pascal(P)
int BME280::getpressure() {
    { hwlib::i2c_write_transaction wtrans = ((hwlib::i2c_bus*)(bus))->write(address);
    wtrans.write(press_reg);}

      // read results from temperature adress
    { hwlib::i2c_read_transaction rtrans = ((hwlib::i2c_bus*)(bus))->read(address);
        rtrans.read(results, 3);}
        // formula for pressure
        int Pressure;
        int32_t raw_press = get_raw(results[0], results[1], results[2]);
        var1= ((double)T_fine/2.0) - 64000.0;
        var2 = var1 * var1 * ((double)dig_P6) / 32768.0;
        var2 =var2 + var1 * ((double)dig_P5) *2.0;
        var2 = (var2/4.0) + (((double)dig_P4) * 65536.0);
        var1 = (((double)dig_P3) * var1 * var1 / 524288.0 + ((double)dig_P2) * var1) / 524288.0;
        var1 = (1.0 + var1 / 32768.0)* ((double)dig_P1);
        if(var1 == 0 ){
            Pressure =0;
        }
        Pressure = 1048576.0 - (double)raw_press;
        Pressure = (Pressure- (var2 / 4096.0)) * 6250.0 / var1;
        var1 = ((double)dig_P9) * Pressure * Pressure / 2147483648.0;
        var2= Pressure* ((double)dig_P8) / 32768.0;
        Pressure = Pressure + (var1 + var2 + ((double) dig_P7)) / 16.0;
        return Pressure;
 }


/// \brief
    /// get humidity sensor bytes and actual humidity value
    /// \details
    /// function to get the 2 bytes from the humidity sensor and calculate the actual humidity in reletive humidty percentage (%rH)
double BME280::gethumidity(){
    
    { hwlib::i2c_write_transaction wtrans = ((hwlib::i2c_bus*)(bus))->write(address);
        wtrans.write(hum_reg);}

      // read results from temperature adress
    { hwlib::i2c_read_transaction rtrans = ((hwlib::i2c_bus*)(bus))->read(address);
        rtrans.read(results, 2);}
    // put 2 bytes into 1 16 bits number
    int32_t raw_hum = 0x00;
    raw_hum = (raw_hum|results[0]) << 8;
    raw_hum = (raw_hum|results[1]);
    
	// formula for Humidity in %rH
    int var_H;
    
    var_H = (((double)T_fine) - 76800);
    var_H = (raw_hum - (((double)dig_H4) * 64.0 + ((double)dig_H5) / 16384.0 * var_H)) *
    (((double)dig_H2) /  65536.0 * (1.0 + ((double)dig_H6) / 67108864.0 * var_H * (1.0 + ((double)dig_H3) / 67108864.0 * var_H)));
    var_H = var_H *(1.0 - ((double)dig_H1) * var_H / 524288.0);
    if(var_H > 100.0){
        var_H = 100.0;
    }
    else if(var_H < 0.0){
        var_H = 0.0;
    }
    return var_H;
    
    
    
}
