/***********************************************************************
*  author ::       Kenan Yildirim                                                                                                                                                                                                 
* File ::              Oled.cpp                                                                                                                                                                                                           
* Date::           29 - 06 - 2022                                                                                                                                                                                                  
* copyright:    Kenan Yildirim 2022
*                                                                                                                                                                                                                                                    
*  Distributed under the Boost Software License, Version 1.0.
* (See accompanying file LICENSE_1_0.txt or copy at 
* http://www.boost.org/LICENSE_1_0.txt)
***********************************************************************/
#include "Oled.hpp"


void Oled::print(int temperature, int pressure, int humidity, int count, int afk_count, int sw2_count){
    
    
    if(count == 0){
        header
         << "\f" << "Turk weerstatun";
         
         if(temperature != 0xFFFF){
             if(sw2_count == 0){
                header
                << "\t0302" << temperature<< "C";
             }
             else if (sw2_count == 1){
                 header
                 << "\t0302" << temperature +273<< "K";
                 }
             else if (sw2_count == 2){
                 header
                 << "\t0302" << (int)(temperature * 1.8 + 32)<< "F";
                 }
            
         }
         else{
             header
             <<"\t0302" << "Disabled";
             }
        header
         << "\t0003" << "=================";
         
         
         if(pressure != 0xFFFF){
            header
            << "\t0304" << pressure <<" Pa";
         }
         else{
             header
             <<"\t0304" << "Disabled";
             }
         header
         << "\t0005" << "=================";
         if(humidity != 0xFFFF){
            header
            << "\t0306" << humidity << "%rH";
         }
         else{
             header
             <<"\t0306" << "Disabled";
             }

    }
    else if(count == 1){
        header
        <<"\t0001" << "---TEMPRATUR---";
        
        if(temperature != 0xFFFF){
            if(sw2_count == 0){
                 big_header
            << "\t0202" << temperature<< "C";
            }
            else if(sw2_count == 1){
                 big_header
            << "\t0202" << temperature + 273<< "K";
            }
            else if(sw2_count == 2){
                 big_header
            << "\t0202" << (int)(temperature * 1.8 +32)<< "F";
            }
            
            
            
            }
        else{
            big_header
            << "\t0202" << "disabled";
            }
    } 
    
    else if(count == 2){
        header
        <<"\t0201" << "---DROEK---";
        
        if(pressure != 0xFFFF){
            big_header
            << "\t0102" << pressure/1000<< "hPa";
            }
        else{
            big_header
            << "\t0202" << "disabled";
            }
        }
    
    else if (count == 3){
        header
        <<"\t0201" << "---NAT HIJD---";
        
        
        if(humidity != 0xFFFF){
            big_header
            << "\t0102" << humidity<< "%Rh";
            }
        else{
            big_header
            << "\t0202" << "disabled";
            }
            
        }
    
    else if(count == 4){
        big_header
        << "\t0200" << "TURK"
        << "\t0201" << "WER-"
        << "\t0102" << "STATUN"
        << "\t0003" << "BY Kenan";
        }
    header
    << hwlib::flush;
    big_header
    << hwlib::flush;
   
}

void Oled::clear(){
    oled.clear();
    }

    