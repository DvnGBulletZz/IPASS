/***********************************************************************
*  author ::       Kenan Yildirim                                                                                                                                                                                                     
* File ::              oled.hpp                                                                                                                                                                                                           
* Date::           29 - 06 - 2022                                                                                                                                                                                                  
* copyright:    Kenan Yildirim 2022
*                                                                                                                                                                                                                                                    
*  Distributed under the Boost Software License, Version 1.0.
* (See accompanying file LICENSE_1_0.txt or copy at 
* http://www.boost.org/LICENSE_1_0.txt)
***********************************************************************/
#ifndef OLED_HPP
#define OLED_HPP
#include "hwlib.hpp"

class Oled
{
    hwlib::i2c_bus_bit_banged_scl_sda & bus;
   
   hwlib::glcd_oled oled;
   hwlib::font_default_8x8 font;
   hwlib::font_default_16x16 big_font;
    hwlib::terminal_from header;
    hwlib::terminal_from big_header;
     
public:
   
   Oled(hwlib::i2c_bus_bit_banged_scl_sda & bus, uint8_t adress): 
    bus(bus),
    oled(hwlib::glcd_oled(bus, adress)),
    font(hwlib::font_default_8x8()),
    big_font(hwlib::font_default_16x16()),
    header(hwlib::terminal_from( oled, font )),
    big_header(hwlib::terminal_from( oled, big_font ))
    {}
   /// \brief
    /// print to oled
    /// \details
    /// function makes it what ever you put in it will print to the oled
   void print(int temperature, int pressure, int humidity, int count, int afk_count, int sw2_count);
    /// \brief
    ///  clears oled
    /// \details
    /// clears the whole oled screen
    void clear();
    
	

};

#endif // OLED_HPP
