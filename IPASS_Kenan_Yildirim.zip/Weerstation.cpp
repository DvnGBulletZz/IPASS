/***********************************************************************
*  author ::       Kenan Yildirim                                                                                                                                                                                                     
* File ::              weerstation.hpp                                                                                                                                                                                                          
* Date::           29 - 06 - 2022                                                                                                                                                                                                  
* copyright:    Kenan Yildirim 2022
*                                                                                                                                                                                                                                                    
*  Distributed under the Boost Software License, Version 1.0.
* (See accompanying file LICENSE_1_0.txt or copy at 
* http://www.boost.org/LICENSE_1_0.txt)
***********************************************************************/
#include "Weerstation.hpp"





void Weerstation::values(){
        if(tempsensor == nullptr){
            temperature = 0XFFFF;}
        
        else{gettemp();}
        if(humidsensor == nullptr){
            humidity = 0XFFFF;}
        else{gethum();}
        if(pressuresensor == nullptr){
            pressure = 0XFFFF;
        }
        else{getpress();}
}   


void Weerstation::readswitch(hwlib::target::pin_in &sw1, hwlib::target::pin_in &sw2){
    
    bool switchstate1 = sw1.read();
    bool switchstate2 = sw2.read();
    
    if(switchstate2){
        window.clear();
        sw2_count++;
        afk_count = 0;
        if(sw2_count > 2){
            sw2_count =0 ;
            }
        
        }
    
    hwlib::cout << switchstate1 << hwlib::endl;
     if(switchstate1){
         bme280.setmode(mode_normal);
         window.clear();
         count++;
         afk_count = 0;
         if(count > 3){
             count =0;
        }
    } 
    else if (afk_count < 40 && switchstate1 == false && switchstate2 == false && count != 4 ){
        afk_count++;
        hwlib::cout << afk_count<< hwlib::endl ;
        }
    if(afk_count == 40){
        window.clear();
        bme280.setmode(mode_sleep);
        count = 4;
        }
        hwlib::cout << count<< hwlib::endl ;
        
    
        
    
}
     
void Weerstation::gettemp(){temperature= (*tempsensor).gettemp();}
void Weerstation::getpress(){pressure =  (*pressuresensor).getpressure();}
void Weerstation::gethum(){humidity = (*humidsensor).gethumidity();}

void Weerstation::print(){
        values();
        window.print(temperature, pressure, humidity, count, afk_count, sw2_count);
}
void Weerstation::clear(){
        window.clear();
    
    }

void Weerstation::testcases(unsigned int & n){
    
    for(unsigned int i = 0 ; i < n; i++){
        gettemp();
        gethum();
        getpress();
        hwlib::cout << i << hwlib::endl;
        hwlib::cout << "testcase temperature: ";
        if(temperature >20 && temperature <30){
            hwlib::cout << "passed" << hwlib::endl;
        }
        else{
            hwlib::cout << "failed" << hwlib::endl;
        }
        hwlib::cout << "testcase pressure: ";
        if(pressure > 97000 && temperature <105000){
            hwlib::cout << "passed" << hwlib::endl;
        }
        else{
            hwlib::cout << "failed" << hwlib::endl;
        }
        hwlib::cout << "testcase humidity: ";
        if(humidity > 40 && humidity <86){
            hwlib::cout << "passed" << hwlib::endl;
        }
        else{
            hwlib::cout << "failed" << hwlib::endl;
        }
        hwlib::wait_ms(100);
    }
    
}