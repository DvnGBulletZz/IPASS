/***********************************************************************
*  author ::       Kenan Yildirim                                                                                                                                                                                                     
* File ::              temp_sensor.hpp                                                                                                                                                                                                          
* Date::           29 - 06 - 2022                                                                                                                                                                                                  
* copyright:    Kenan Yildirim 2022
*                                                                                                                                                                                                                                                    
*  Distributed under the Boost Software License, Version 1.0.
* (See accompanying file LICENSE_1_0.txt or copy at 
* http://www.boost.org/LICENSE_1_0.txt)
***********************************************************************/
#ifndef WEERSTATION_HPP
#define WEERSTATION_HPP
#include "hwlib.hpp"
#include "BME280.hpp"
#include "constvalues.hpp"
#include "Oled.hpp"
#include "temp_sensor.hpp"
#include "pressure_sensor.hpp"
#include "humidity_sensor.hpp"
class Weerstation
{   
    int temperature;
    int pressure;
    int humidity;
    int count = 4;
    int afk_count = 0;
    int sw2_count = 0;
    Oled &window;
    BME280 & bme280;
	temp_sensor * tempsensor;
    pressure_sensor * pressuresensor;
    humidity_sensor * humidsensor;


    
public:

    Weerstation(Oled &window,BME280& bme280, temp_sensor * tempsensor = nullptr, pressure_sensor * pressuresensor = nullptr, humidity_sensor * humidsensor = nullptr): 
    window(window),
    bme280(bme280),
    tempsensor(tempsensor),
    pressuresensor(pressuresensor),
    humidsensor(humidsensor)
    {gettemp();}
    
    /// \brief
    /// get values
    /// \details
    /// grabs values from the bme280 from the abstracts classes
    void values(); 
    
    /// \brief
    /// read switch values
    /// \details
    /// read the values of the switches given as a bool
    void readswitch(hwlib::target::pin_in &sw1, hwlib::target::pin_in &sw2);
    
     /// \brief
    ///  gets temperature from bme280
    /// \details
    /// gets temperature value from the bme280 chip
    void gettemp();
    
     /// \brief
    ///  gets pressure from bme280
    /// \details
    /// gets pressure value from the bme280 chip
    void getpress();
    
     /// \brief
    ///  gets humidity from bme280
    /// \details
    /// gets humidity value from the bme280 chip
    void gethum();
    
     /// \brief
    ///  print function to oled
    /// \details
    /// print function to go to the oled class
    void print();
     /// \brief
    ///  clear function for oled
    /// \details
    /// clear function for the oled class
    void clear();
    
    
     /// \brief
    ///  testcases
    /// \details
    /// test cases for the application
    void testcases(unsigned int & n);
    
	

};

#endif // WEERSTATION_HPPs