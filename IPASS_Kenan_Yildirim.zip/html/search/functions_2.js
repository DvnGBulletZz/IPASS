var searchData=
[
  ['print_0',['print',['../class_oled.html#a1c50e7b516b00d674eb789c26c32f970',1,'Oled::print()'],['../class_weerstation.html#a0d8a4df0197aed371c077b4746a19f2d',1,'Weerstation::print()']]]
];
