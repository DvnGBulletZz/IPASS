var searchData=
[
  ['readswitch_0',['readswitch',['../class_weerstation.html#a6fae8ead3d41e8db9f3423550921f478',1,'Weerstation']]]
];
