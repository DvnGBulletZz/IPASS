var searchData=
[
  ['values_0',['values',['../class_weerstation.html#a4f4549162ff1f8d5682712130eed29e7',1,'Weerstation']]]
];
