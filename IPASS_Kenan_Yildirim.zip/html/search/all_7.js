var searchData=
[
  ['set_5fsettings_0',['set_settings',['../class_b_m_e280.html#a9e7ce8879176eb8dac162ad6458e5b75',1,'BME280']]],
  ['setcompensation_1',['setcompensation',['../class_b_m_e280.html#a700f630cac909c60e16b57edfe870953',1,'BME280']]],
  ['setmode_2',['setmode',['../class_b_m_e280.html#a31266b03f50f1c57d2c63401c67e0a4a',1,'BME280']]]
];
