var searchData=
[
  ['temp_5fsensor_0',['temp_sensor',['../classtemp__sensor.html',1,'']]],
  ['temp_5fsensor_2ehpp_1',['temp_sensor.hpp',['../temp__sensor_8hpp.html',1,'']]],
  ['testcases_2',['testcases',['../class_weerstation.html#a813ca898b58e3633667614b7e99c753f',1,'Weerstation']]]
];
