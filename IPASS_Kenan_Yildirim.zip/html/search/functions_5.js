var searchData=
[
  ['testcases_0',['testcases',['../class_weerstation.html#a813ca898b58e3633667614b7e99c753f',1,'Weerstation']]]
];
